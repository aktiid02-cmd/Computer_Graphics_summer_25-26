#!/bin/bash
# Build and Run Script for Radisson Blu OpenGL Application on macOS

echo "==========================================================="
echo " Compiling Radisson Blu Chattogram OpenGL Project... "
echo "==========================================================="

clang++ -w main.cpp -o main_app -framework OpenGL -framework GLUT

if [ $? -eq 0 ]; then
    echo "[BUILD SUCCESS] Binary executable 'main_app' generated."
    echo "Starting application..."
    ./main_app
else
    echo "[BUILD ERROR] Compilation failed."
    exit 1
fi
